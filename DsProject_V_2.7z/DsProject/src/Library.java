import java.util.ArrayList;
import java.util.Hashtable;
import java.util.TreeSet;

public class Library {
    //make attributes private
    private Hashtable<Integer, Book> Books;
    private Book[] Latest;
    private ArrayList<Book>[] Genre; // 0-9 index where each is a genre. Genre is an enum.
    //I do not know how to implement Heaptrees xd
    private TreeSet<Book> Popular; // use Lab heaptree or learn treeset.

    public Library(){
        //initialising attributes
        Genre= new ArrayList[10];
        Latest=new Book[15];
        //Popular needs to be reformatted into the custom heaptree. Therefore I am not including it in the initialization now. -Abdur Rehman.

    }

    public void addBook(String title, String Author, Genre genre, String pubDate,String ISBN, String Publisher) {
        // add to the Big General Storage,
        //check latest, by genre and popular and then insert the pointers.
        Book b = new Book(Author,title,genre,pubDate, ISBN,Publisher);int key=0;
        for(int i =0; i<title.length()-1;i++){ // this method of producing key is used since it allows us to use the title as the hash value.
         key += title.codePointAt(i);          // we can alternatively use the Books.length function to gain the number of keys inside the HashTable.
        }

        Book p=b;

        Books.putIfAbsent(key, b); //adding to BGS

        if((pubDate.contains("2020")) || (pubDate.contains("2021")) || (pubDate.contains("2022")) || (pubDate.contains("2023")) ){// this condition needs to be improved
            for(int i =0; i< Latest.length-1;i++){
                if(Latest[i]!=null){
                    Latest[i]=p;
                    break;
                }
            }
        }

        switch (genre) { // this is for adding into the Genre

            case ScienceFiction: Genre[0].add(p);
            case Fantasy: Genre[1].add(p);
            case Mystery: Genre[2].add(p);
            case Thriller: Genre[3].add(p);
            case HistoricalFiction: Genre[4].add(p);
            case Horror: Genre[5].add(p);
            case Biography: Genre[6].add(p);
            case Selfhelp: Genre[7].add(p);
            case Romance: Genre[8].add(p);
            case YoungAdult: Genre[9].add(p);

        }


        // For the addition by popularity the Heaptree and the review addition needs to be done first. This as lazy as I am, will leave to you guys.:D
    }

    public Book getBook(String title) {
        ;int key=0;
        for(int i =0; i<title.length()-1;i++){
            key += title.codePointAt(i);
        }

        return Books.get(key);

    }

    public Book[] getSortedByLatestBooks() {
        return null;
    }
    public void getSortedByPopularBooks() {
        // return most popular using heaptree.
    }
    public void getSortedByGenreBooks(Genre genre) {
        //return by Genre 10 books
    }

    public void DeleteBook(String title) {
        //once we delete from the BGS
        //  update all the substorages, except genre.
    }

    public void rearrangeHeapTree() {
    //

    }

    public void updateLatest() {
    //

    }

}
