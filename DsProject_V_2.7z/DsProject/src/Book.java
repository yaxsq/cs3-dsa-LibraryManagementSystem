import java.sql.Time;
import java.time.Clock;
import java.util.LinkedList;

public class Book {
    //make attributes private
    private String Author;
    private String ISBN;
    private String Publisher;
    private String Title;
    private Genre genre;
    private LinkedList<Review> Reviews;
    private String pubDate;

    public Book(String author, String title, Genre genre, String pubDate, String ISBN, String Publisher) {
        Author = author;
        Title = title;
        this.genre = genre;
        this.pubDate=pubDate;
        this.Publisher=Publisher;
        this.ISBN=ISBN;

    }

    public String getISBN() {
        return ISBN;
    }

    public String getPublisher() {
        return Publisher;
    }

    public String getAuthor() {
        return Author;
    }

    public String getTitle() {
        return Title;
    }

    public String getGenre() {
        return genre.toString();
    }

    public LinkedList<Review> getReviews() {
        return Reviews;
    }

    public String getPubDate() {
        return pubDate;
    }

    @Override
    public String toString() {
        return "Book{" +
                "Author='" + Author + '\'' +
                ", Title='" + Title + '\'' +
                ", genre='" + genre + '\'' +
                ", Reviews=" + Reviews +
                ", pubDate='" + pubDate + '\'' +
                '}';
    }
    public void AddReview(Review Review){
        Reviews.add(Review);
    }
}
